package com.example.platehunter

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Sends one recorded street (AAC audio) to Gemini and gets the plates back as JSON. Call from a worker thread. */
object GeminiStreetTranscriber {
    class Item(val street: String, val pin: String, val plate: String, val type: String, val t: Double?, val unclear: Boolean)
    class Result(val items: List<Item>, val notes: String)

    // Fast stable first choice; fallback is retained for model availability errors.
    private val models = listOf("gemini-2.5-flash", "gemini-3-flash-preview")

    private val PROMPT = """
أنت تفرّغ تسجيلًا صوتيًا لشارع يقرأ فيه المسجِّل لوحات سيارات سعودية بصوته. أعد JSON فقط، بلا أي شرح، بهذا الشكل بالضبط:
{"items":[{"street":"...","pin":"...","plate":"...","type":"...","t":0.0,"unclear":false}],"notes":"..."}

القواعد:
- اللوحة = 3 حروف عربية ثم 4 أرقام بدون مسافات. لو قيلت 3 أرقام أضف صفرًا على اليسار (0752)، ولو رقمان صفرين، وهكذا حتى 4 أرقام.
- الأرقام المقسومة (مثل "64 92") تُدمج في رقم واحد (6492).
- الألف تُكتب ا دائمًا (بدون همزة)، والياء ي وليست ى، والهاء ه وليست هـ.
- لو سمعت "ت" ضمن حروف اللوحة اكتبها ط، واذكر ذلك في notes. لا تغيّر ث ولا خ، وإن لم تكن واضحة ضع unclear=true واذكرها في notes.
- النوع يُقال بعد لوحته، وقيمه: امه، ونيت، تاكسي، ميكروباص، نقل. "وايت" = ونيت، "تاكس" = تاكسي. لوحة بلا نوع تُترك خانة type فارغة. لو قيل نوع قبل أي لوحة في بداية الشارع فتجاهله واذكره في notes.
- اسم الشارع: غالبًا لن يُذكر في التسجيل. إن لم يُذكر اسم شارع فاترك street فارغًا تمامًا ولا تخترع اسمًا. وإن قيل اسم شارع فضعه في street لكل لوحة تليه حتى شارع جديد. كلمة ملتصقة برقم مثل "نقل18" جزء من اسم الشارع، أما "نقل" متبوعة بلوحة فهي نوع.
- "دبوس N" يسري على كل اللوحات بعده حتى دبوس آخر أو شارع جديد، ويُصفَّر عند شارع جديد؛ أول مجموعة بلا دبوس. ضع قيمته (N فقط، بدون كلمة دبوس) في حقل pin، واتركه فارغًا إن لم يوجد. دبوس حرفي (مثل "دبوس ب") يُكتب كما قيل في pin واذكره في notes.
- تجاهل أي كلام ليس لوحة أو اسم شارع أو دبوسًا أو نوعًا.
- حافظ على ترتيب التسجيل ولا تحذف اللوحات المكررة.
- t = الثانية (رقم عشري) من بداية التسجيل التي بدأ عندها نطق اللوحة تقريبًا.
- لا تخمّن حرفًا أو رقمًا غير مسموع؛ اكتب ما سمعته وضع unclear=true.
""".trim()

    private fun cleanPlate(raw: String): Pair<String, Boolean> {
        val s = PlateParser.normDigits(raw).replace("ـ", "").replace(Regex("\\s+"), "")
            .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ى', 'ي')
        val letters = s.takeWhile { it in '\u0621'..'\u064A' }
        val digits = s.drop(letters.length)
        return if (letters.length == 3 && digits.isNotEmpty() && digits.length <= 4 && digits.all { it in '0'..'9' })
            Pair(letters + digits.padStart(4, '0'), false) else Pair(s, true)
    }

    private fun cleanType(raw: String): String {
        val t = raw.trim().replace('ى', 'ي')
        return when (t) {
            "وايت", "وانيت", "ونيت" -> "ونيت"
            "تاكس", "تكسي", "تاكسي" -> "تاكسي"
            "يامه", "ياما", "امه", "أمه", "إمه" -> "امه"
            else -> t
        }
    }

    /**
     * Small recordings are sent inline for speed. Larger recordings use the Gemini Files API
     * so base64 expansion does not make the request exceed inline payload limits.
     */
    fun transcribe(apiKey: String, file: File): Result {
        if (!file.exists() || file.length() < 1000L) throw IllegalStateException("ملف التسجيل فارغ أو غير مكتمل")
        val useFileApi = file.length() > 4L * 1024L * 1024L
        var uploadedUri: String? = null
        var uploadedName: String? = null
        try {
            if (useFileApi) {
                val uploaded = uploadAudio(apiKey, file)
                uploadedUri = uploaded.first
                uploadedName = uploaded.second
            }
            val audioPart = if (uploadedUri != null) {
                JSONObject().put("file_data", JSONObject().put("mime_type", "audio/aac").put("file_uri", uploadedUri))
            } else {
                JSONObject().put("inline_data", JSONObject().put("mime_type", "audio/aac")
                    .put("data", Base64.encodeToString(file.readBytes(), Base64.NO_WRAP)))
            }
            val bytes = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray()
                    .put(audioPart)
                    .put(JSONObject().put("text", PROMPT)))))
                .put("generationConfig", JSONObject().put("temperature", 0).put("responseMimeType", "application/json"))
                .toString().toByteArray(Charsets.UTF_8)
            var lastErr = "لم يرد Gemini"
            for (m in models) {
                for (attempt in 0..1) {
                    var conn: HttpURLConnection? = null
                    try {
                        conn = (URL("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent").openConnection() as HttpURLConnection).apply {
                            requestMethod = "POST"
                            connectTimeout = 30000
                            readTimeout = 120000
                            doOutput = true
                            setRequestProperty("Content-Type", "application/json; charset=utf-8")
                            setRequestProperty("x-goog-api-key", apiKey)
                            setFixedLengthStreamingMode(bytes.size)
                        }
                        conn.outputStream.use { it.write(bytes) }
                        val code = conn.responseCode
                        if (code in 200..299) {
                            val raw = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                            return parse(raw)
                        }
                        val err = conn.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                        lastErr = "HTTP $code ${err.take(300)}"
                        if (code == 401 || code == 403) throw IllegalStateException("مفتاح Gemini غير صحيح أو لا يملك الصلاحية (HTTP $code)")
                        if (code == 429 || code >= 500) {
                            if (attempt < 2) { Thread.sleep(1000L * (attempt + 1)); continue }
                        }
                        if (code == 400 || code == 404) break // try fallback model
                        if (attempt < 2 && code >= 500) continue
                        break
                    } catch (e: IOException) {
                        lastErr = "تعذر الاتصال بخدمة Gemini: ${e.message ?: "انقطع الاتصال أثناء الإرسال"}"
                        if (attempt < 2) {
                            try { Thread.sleep(1000L * (attempt + 1)) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
                            continue
                        }
                        // Move to the fallback model after retries for this model.
                    } finally { conn?.disconnect() }
                }
            }
            throw IllegalStateException(lastErr)
        } finally {
            // Files API objects are temporary; delete best-effort to avoid leaving uploaded audio behind.
            if (!uploadedName.isNullOrBlank()) deleteUploaded(apiKey, uploadedName)
        }
    }

    private fun uploadAudio(apiKey: String, file: File): Pair<String, String> {
        var start: HttpURLConnection? = null
        try {
            start = (URL("https://generativelanguage.googleapis.com/upload/v1beta/files?key=${java.net.URLEncoder.encode(apiKey, "UTF-8")}").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 30000; readTimeout = 60000; doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("X-Goog-Upload-Protocol", "resumable")
                setRequestProperty("X-Goog-Upload-Command", "start")
                setRequestProperty("X-Goog-Upload-Header-Content-Length", file.length().toString())
                setRequestProperty("X-Goog-Upload-Header-Content-Type", "audio/aac")
            }
            start.outputStream.use { it.write(JSONObject().put("file", JSONObject().put("display_name", file.name)).toString().toByteArray(Charsets.UTF_8)) }
            val code = start.responseCode
            if (code !in 200..299) {
                val err = start.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                throw IllegalStateException("فشل تجهيز رفع التسجيل (HTTP $code): ${err.take(200)}")
            }
            val uploadUrl = start.getHeaderField("X-Goog-Upload-URL")
                ?: throw IllegalStateException("Gemini لم يُرجع رابط رفع التسجيل")
            start.disconnect(); start = null
            var put: HttpURLConnection? = null
            try {
                put = (URL(uploadUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 30000; readTimeout = 180000; doOutput = true
                    setRequestProperty("Content-Length", file.length().toString())
                    setRequestProperty("X-Goog-Upload-Offset", "0")
                    setRequestProperty("X-Goog-Upload-Command", "upload, finalize")
                    setFixedLengthStreamingMode(file.length())
                }
                put.outputStream.use { out -> file.inputStream().use { input -> input.copyTo(out, 64 * 1024) } }
                val putCode = put.responseCode
                val response = (if (putCode in 200..299) put.inputStream else put.errorStream)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                if (putCode !in 200..299) throw IllegalStateException("فشل رفع التسجيل إلى Gemini (HTTP $putCode): ${response.take(200)}")
                val fileObj = JSONObject(response).optJSONObject("file") ?: JSONObject(response)
                val uri = fileObj.optString("uri")
                val name = fileObj.optString("name")
                if (uri.isBlank() || name.isBlank()) throw IllegalStateException("رد رفع التسجيل من Gemini غير مكتمل")
                return Pair(uri, name)
            } finally { put?.disconnect() }
        } catch (e: IOException) {
            throw IOException("تعذر رفع التسجيل إلى Gemini: ${e.message ?: "انقطع الاتصال"}", e)
        } finally { start?.disconnect() }
    }

    private fun deleteUploaded(apiKey: String, name: String) {
        var conn: HttpURLConnection? = null
        try {
            conn = (URL("https://generativelanguage.googleapis.com/v1beta/$name?key=${java.net.URLEncoder.encode(apiKey, "UTF-8")}").openConnection() as HttpURLConnection).apply {
                requestMethod = "DELETE"; connectTimeout = 5000; readTimeout = 5000
            }
            conn.responseCode // best effort only
        } catch (_: Exception) { } finally { conn?.disconnect() }
    }

    private fun parse(raw: String): Result {
        val parts = JSONObject(raw).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            ?: throw IllegalStateException("رد فارغ من Gemini")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.optJSONObject(i)?.optString("text").orEmpty())
        var text = sb.toString().trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val obj = if (text.startsWith("[")) JSONObject().put("items", JSONArray(text)) else JSONObject(text)
        val arr = obj.optJSONArray("items") ?: JSONArray()
        val items = ArrayList<Item>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val (plate, bad) = cleanPlate(o.optString("plate"))
            if (plate.isBlank()) continue
            items.add(Item(o.optString("street").trim(), o.optString("pin").replace("دبوس", "").trim(), plate, cleanType(o.optString("type")),
                if (o.has("t") && !o.isNull("t")) o.optDouble("t").takeIf { it.isFinite() } else null,
                bad || o.optBoolean("unclear", false)))
        }
        return Result(items, obj.optString("notes").trim())
    }
}
